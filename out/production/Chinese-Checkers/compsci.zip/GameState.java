
public enum GameState {
	STATE_PIECE_SELECTED,
	STATE_IDLE,
}
