
public class ArrayCoordinate {
 public int row;
 public int column;
 
 public ArrayCoordinate(int a, int b) {
  this.row = a;
  this.column = b;
 }
 
 public void displayCoordinate() {
  System.out.println(row + ", " + column);
 }
 
}
